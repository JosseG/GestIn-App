package com.nsgej.gestinapp.ui.menu.maintenance.producto

import android.os.Binder
import android.os.Bundle
import android.text.Editable
import android.transition.TransitionInflater
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.viewmodel.ViewModelFactoryDsl
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavDirections
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.nsgej.gestinapp.MiAplicacion
import com.nsgej.gestinapp.R
import com.nsgej.gestinapp.databinding.FragmentMntmProductoActualizacionBinding
import com.nsgej.gestinapp.domain.model.Producto
import com.nsgej.gestinapp.domain.model.toDomain
import com.nsgej.gestinapp.ui.adapter.producto.ProductosEspecificoAdapter
import com.nsgej.gestinapp.ui.adapter.producto.ProductosEspecificoViewHolder
import com.nsgej.gestinapp.viewmodel.producto.ProductoViewModel
import dagger.hilt.android.AndroidEntryPoint
import java.util.*


@AndroidEntryPoint
class MntmProductoActualizacionFragment : Fragment() {

    private var _binding: FragmentMntmProductoActualizacionBinding? = null
    val binding get() = _binding!!

    private val args by navArgs<MntmProductoActualizacionFragmentArgs>()
    //private val productoViewModel by viewModels<ProductoViewModel>()

//------------------------------------------------------------
    /*val productoViewModel by viewModels<ProductoViewModel> {
        val productopru = requireActivity().application as MiAplicacion
       viewModelFactory { productopru}
    }*/
//-------------------------------------------------------------

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentMntmProductoActualizacionBinding.inflate(inflater, container, false)
        sharedElementEnterTransition =
            TransitionInflater.from(context).inflateTransition(android.R.transition.move)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.txtCodBarra.editText?.text=Editable.Factory.getInstance().newEditable(args.codigobarraaplicar)
        binding.txtDescripcion.editText?.text=Editable.Factory.getInstance().newEditable(args.descripcion)
        binding.txtMarca.editText?.text=Editable.Factory.getInstance().newEditable(args.marcaaplica)
//preguntar como pasar la imagen-----------------------------------
        Log.i("id",args.imagen.toString())
        binding.imgvProducto .transitionName = args.imagen
        binding.imgvProducto.setImageResource(R.drawable.producto)
  //--------------------------------------------------------------
        binding.btnActualizar.setOnClickListener {
            binding.txtCodBarra.error = null
            binding.txtDescripcion.error = null
            binding.txtMarca.error = null

            val codigoBarra = binding.txtCodBarra.editText?.text.toString()
            val Codigovalidar = "[A-Za-z\\d\\-_\\sÑñ]{1,50}".toRegex()
            if (!Codigovalidar.matches(codigoBarra)) {
                binding.txtCodBarra.error = "Campo Solicitado"
                return@setOnClickListener
            }
            val descripcion = binding.txtDescripcion.editText?.text.toString()
            val descripcionValidar = "[A-Za-z\\d\\-_\\sÑñ]{1,50}".toRegex()
            if (!descripcionValidar.matches(descripcion)) {
                binding.txtDescripcion.error = "Campo Solicitado"
                return@setOnClickListener
            }
            val marca = binding.txtMarca.editText?.text.toString()
            val Marcavalidar = "[A-Za-z\\d\\-_\\sÑñ]{1,50}".toRegex()
            if (!Marcavalidar.matches(marca)) {
                binding.txtMarca.error = "Campo Solicitado"
                return@setOnClickListener
            }
            /*var producto= Producto(codigoBarra, descripcion, marca)
            Log.i("act",producto.toString())
            productoViewModel.actualizar(producto)*/

        }
        binding.btnEliminar.setOnClickListener {
            binding.txtCodBarra.error = null
            binding.txtDescripcion.error = null
            binding.txtMarca.error = null

            val codigoBarra = binding.txtCodBarra.editText?.text.toString()
            val Codigovalidar = "[A-Za-z\\d\\-_\\sÑñ]{1,50}".toRegex()
            if (!Codigovalidar.matches(codigoBarra)) {
                binding.txtCodBarra.error = "Campo Solicitado"
                return@setOnClickListener
            }
            val descripcion = binding.txtDescripcion.editText?.text.toString()
            val descripcionValidar = "[A-Za-z\\d\\-_\\sÑñ]{1,50}".toRegex()
            if (!descripcionValidar.matches(descripcion)) {
                binding.txtDescripcion.error = "Campo Solicitado"
                return@setOnClickListener
            }
            val marca = binding.txtMarca.editText?.text.toString()
            val Marcavalidar = "[A-Za-z\\d\\-_\\sÑñ]{1,50}".toRegex()
            if (!Marcavalidar.matches(marca)) {
                binding.txtMarca.error = "Campo Solicitado"
                return@setOnClickListener
            }
           /* var producto = Producto(nombre, codigo, cantidad.toInt())
            productoViewModel.elimina(producto)*/

            findNavController().navigate(R.id.action_mntmProductoActualizacionFragment_to_mntmProductoListaEspFragment)
        }



        binding.btnRegresar.setOnClickListener {
            val direction: NavDirections =
                MntmProductoActualizacionFragmentDirections.actionMntmProductoActualizacionFragmentToMntmProductoListaEspFragment(
                    idtipoproducto = args.idtipoproducto,
                    nombretipoproducto = args.nombretipoproducto
                )
            findNavController().navigate(direction)
            //findNavController().navigate(R.id.action_mntmProductoActualizacionFragment_to_mntmProductoListaEspFragment)

        }
    }
}



