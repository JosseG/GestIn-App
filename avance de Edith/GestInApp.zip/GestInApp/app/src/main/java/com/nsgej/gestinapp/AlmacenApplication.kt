package com.nsgej.gestinapp

import android.app.Application

class AlmacenApplication : Application() {
}