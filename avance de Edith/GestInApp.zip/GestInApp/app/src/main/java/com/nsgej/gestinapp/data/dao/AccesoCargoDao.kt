package com.nsgej.gestinapp.data.dao

import androidx.room.Dao


@Dao
interface AccesoCargoDao {
}