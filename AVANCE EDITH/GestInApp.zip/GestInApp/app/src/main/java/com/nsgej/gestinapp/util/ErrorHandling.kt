package com.nsgej.gestinapp.util

class ErrorHandling {
}